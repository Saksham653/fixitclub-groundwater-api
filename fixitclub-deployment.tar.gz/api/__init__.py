"""
API package for Groundwater ML Analysis Platform.
"""