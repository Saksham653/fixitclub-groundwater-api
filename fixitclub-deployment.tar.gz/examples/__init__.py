"""
Example test functions for ML modules.
"""

from .test_functions import run_example_tests

__all__ = ['run_example_tests']
